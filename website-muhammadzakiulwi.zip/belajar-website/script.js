// Menunggu hingga seluruh konten halaman (DOM) selesai dimuat
document.addEventListener('DOMContentLoaded', () => {

    // --- 1. INTERAKSI DROPDOWN MENU (MOBILE) ---
    const hamburgerMenu = document.getElementById('hamburgerMenu');
    const navLinks = document.querySelector('.nav-links');

    hamburgerMenu.addEventListener('click', () => {
        navLinks.classList.toggle('show');
    });

    // --- 2. LOGIKA LOOPING UNTUK MENAMPILKAN KEAHLIAN SECARA DINAMIS ---
    const skillsData = [
        { name: 'HTML5', icon: 'fa-html5' },
        { name: 'CSS', icon: 'fa-css3-alt' },
        { name: 'JavaScript', icon: 'fa-js' },
        { name: 'Git', icon: 'fa-git-alt' },
        
    ];

    const skillsGrid = document.getElementById('skillsGrid');

    // Menggunakan looping (forEach) untuk membuat elemen HTML untuk setiap keahlian
    skillsData.forEach(skill => {
        const skillCard = document.createElement('div');
        skillCard.className = 'skill-card';
        skillCard.innerHTML = `
            <i class="fab ${skill.icon}"></i>
            <p>${skill.name}</p>
        `;
        skillsGrid.appendChild(skillCard);
    });

    // --- 3. LOGIKA SLIDER GAMBAR/KONTEN DINAMIS ---
    const projectsData = [
        {
            title: 'Website Pemesanan Makanan',
            description: 'Website pemesanan makanan yang mudah dan paraktis.',
            image: "./asset/proyek/proyek-1.jpg"
        },
        {
            title: 'Website Sekolah',
            description: 'website sekolah dengan desain yang modern dan minimalis berisikan informasi tentang sekolah.',
            image: "./asset/proyek/proyek-2.jpg"
        },
        {
            title: 'Website Portofolio',
            description: 'Website portofolio yang berisikan tentang latar belakang dan keahlian developer.',
            image: "./asset/proyek/proyek-3.jpg"
        }
    ];

    const projectSlider = document.getElementById('projectSlider');
    const sliderDots = document.getElementById('sliderDots');

    // Menggunakan looping (forEach) untuk membuat slide dan dot navigator
    projectsData.forEach((project, index) => {
        // Buat slide
        const slide = document.createElement('div');
        slide.className = 'slide';
        slide.innerHTML = `
            <img src="${project.image}" alt="${project.title}">
            <div class="slide-content">
                <h3>${project.title}</h3>
                <p>${project.description}</p>
            </div>
        `;
        projectSlider.appendChild(slide);

        // Buat dot
        const dot = document.createElement('span');
        dot.className = 'dot';
        dot.dataset.index = index; // Simpan index di data-attribute
        sliderDots.appendChild(dot);
    });

    // Fungsionalitas slider
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    let currentIndex = 0;
    let autoSlideInterval;

    function showSlide(index) {
        // Logika untuk memastikan index tidak keluar dari batas
        if (index >= slides.length) {
            currentIndex = 0;
        } else if (index < 0) {
            currentIndex = slides.length - 1;
        } else {
            currentIndex = index;
        }

        // Geser slider
        projectSlider.style.transform = `translateX(-${currentIndex * 100}%)`;

        // Update dot aktif
        dots.forEach(dot => dot.classList.remove('active'));
        dots[currentIndex].classList.add('active');
    }

    // Event listener untuk tombol next/prev
    nextBtn.addEventListener('click', () => {
        showSlide(currentIndex + 1);
        resetAutoSlide();
    });

    prevBtn.addEventListener('click', () => {
        showSlide(currentIndex - 1);
        resetAutoSlide();
    });

    // Event listener untuk dots
    dots.forEach(dot => {
        dot.addEventListener('click', (e) => {
            const index = parseInt(e.target.dataset.index);
            showSlide(index);
            resetAutoSlide();
        });
    });
    
    // Fungsi untuk slide otomatis
    function startAutoSlide() {
        autoSlideInterval = setInterval(() => {
            showSlide(currentIndex + 1);
        }, 5000); // Ganti slide setiap 5 detik
    }

    function resetAutoSlide() {
        clearInterval(autoSlideInterval);
        startAutoSlide();
    }

    // Inisialisasi slider
    showSlide(0);
    startAutoSlide();


    // --- 4. FITUR INTERAKTIF LAINNYA ---
    // Update tahun di footer secara dinamis
    const currentYear = document.getElementById('currentYear');
    currentYear.textContent = new Date().getFullYear();
});